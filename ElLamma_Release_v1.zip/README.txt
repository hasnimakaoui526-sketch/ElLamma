اللمة — Release v1.0.0

هذه الحزمة تحتوي على:
1) نسخة الويب/HTML المرتبطة بـ Supabase الجديد.
2) مشروع Android جاهز للبناء باسم التطبيق: اللمة.
3) GitHub Actions لبناء APK Release تلقائيًا.

Supabase project: el-lamma-chat
API: https://bfbzgzletoaxyazugjex.supabase.co/functions/v1/api

لا توجد أسرار أو service_role keys داخل ملفات التطبيق.

مهم: ملف APK النهائي الموقّع للنشر يحتاج مفتاح توقيع Android خاص بالمالك. هذه الحزمة تجهز البناء Release، لكن لا تخزن مفتاح توقيع خاص داخل المشروع.
