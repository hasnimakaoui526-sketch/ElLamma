# El Lamma: no custom rules required for v1.
